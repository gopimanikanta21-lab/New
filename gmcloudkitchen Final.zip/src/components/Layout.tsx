import { Link, Outlet, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, ChefHat } from 'lucide-react';
import { useState } from 'react';
import { useCartStore } from '../store';
import { motion, AnimatePresence } from 'motion/react';

export default function Layout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const cartItems = useCartStore((state) => state.items);
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Menu', path: '/order' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <div className="min-h-screen bg-[#fdfbf7] text-[#2d2a26] font-sans flex flex-col">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-[#fdfbf7]/90 backdrop-blur-md border-b border-[#2d2a26]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-full bg-[#c25e2a] flex items-center justify-center text-white group-hover:scale-105 transition-transform">
                <ChefHat size={24} />
              </div>
              <span className="font-serif text-2xl tracking-tight text-[#2d2a26] font-medium">
                GMCloudKitchen
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`text-sm uppercase tracking-widest font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'text-[#c25e2a]'
                      : 'text-[#5c5853] hover:text-[#2d2a26]'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              <Link
                to="/checkout"
                className="relative p-2 text-[#5c5853] hover:text-[#2d2a26] transition-colors"
              >
                <ShoppingBag size={24} />
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-[#c25e2a] text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {cartCount}
                  </span>
                )}
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center gap-4">
              <Link
                to="/checkout"
                className="relative p-2 text-[#5c5853] hover:text-[#2d2a26] transition-colors"
              >
                <ShoppingBag size={24} />
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-[#c25e2a] text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {cartCount}
                  </span>
                )}
              </Link>
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-[#5c5853] hover:text-[#2d2a26]"
              >
                {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-[#2d2a26]/10 overflow-hidden"
            >
              <div className="px-4 py-6 flex flex-col gap-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`text-lg uppercase tracking-widest font-medium ${
                      location.pathname === link.path
                        ? 'text-[#c25e2a]'
                        : 'text-[#5c5853]'
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-[#f4f0ea] border-t border-[#2d2a26]/10 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <ChefHat size={24} className="text-[#c25e2a]" />
              <span className="font-serif text-xl text-[#2d2a26]">GMCloudKitchen</span>
            </div>
            <p className="text-[#5c5853] text-sm leading-relaxed max-w-xs">
              Authentic Andhra flavors delivered straight to your door. We care about your health and happiness.
            </p>
          </div>
          <div>
            <h4 className="text-[#2d2a26] font-medium uppercase tracking-widest text-sm mb-4">Contact</h4>
            <ul className="text-[#5c5853] text-sm space-y-2">
              <li>+91 9111881159</li>
              <li>hello@gmcloudkitchen.in</li>
              <li>IG: @gmcloudkitchen</li>
            </ul>
          </div>
          <div>
            <h4 className="text-[#2d2a26] font-medium uppercase tracking-widest text-sm mb-4">Location</h4>
            <p className="text-[#5c5853] text-sm leading-relaxed">
              KPHP Colony<br />
              Gajularamaram<br />
              Hyderabad, Telangana
            </p>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-[#2d2a26]/10 text-center text-[#8a857e] text-sm">
          &copy; {new Date().getFullYear()} GMCloudKitchen. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
