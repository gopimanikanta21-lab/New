export interface MenuItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  description: string;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: 'Idly',
    price: 50,
    image: 'https://images.unsplash.com/photo-1589301760014-d929f39ce9b1?auto=format&fit=crop&q=80&w=800',
    category: 'Breakfast',
    description: 'Soft and fluffy steamed rice cakes, served with chutney and sambar.'
  },
  {
    id: '2',
    name: 'Dosa',
    price: 50,
    image: 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&q=80&w=800',
    category: 'Breakfast',
    description: 'Crispy, savory crepe made from fermented rice and lentil batter.'
  },
  {
    id: '3',
    name: 'Puri',
    price: 50,
    image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&q=80&w=800',
    category: 'Breakfast',
    description: 'Deep-fried bread served with a flavorful potato curry.'
  },
  {
    id: '4',
    name: 'Vada',
    price: 50,
    image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&q=80&w=800',
    category: 'Breakfast',
    description: 'Crispy, deep-fried lentil donuts with a soft interior.'
  },
  {
    id: '5',
    name: 'Meals',
    price: 120,
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&q=80&w=800',
    category: 'Lunch',
    description: 'Traditional Andhra full meal with rice, dal, curries, and more.'
  },
  {
    id: '6',
    name: 'Biryani',
    price: 250,
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&q=80&w=800',
    category: 'Lunch',
    description: 'Aromatic basmati rice cooked with tender meat and rich spices.'
  },
  {
    id: '7',
    name: 'Gulab Jamun',
    price: 50,
    image: 'https://images.unsplash.com/photo-1593701461250-d7b2280d5a5a?auto=format&fit=crop&q=80&w=800',
    category: 'Dessert',
    description: 'Soft, deep-fried milk solids soaked in rose-flavored sugar syrup.'
  },
  {
    id: '8',
    name: 'Rava Laddu',
    price: 50,
    image: 'https://images.unsplash.com/photo-1605807646983-377bc5a76493?auto=format&fit=crop&q=80&w=800',
    category: 'Dessert',
    description: 'Sweet balls made with roasted semolina, ghee, and nuts.'
  }
];
