import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Instagram } from 'lucide-react';

export default function Contact() {
  return (
    <div className="w-full bg-[#fdfbf7] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-6 block">
            Get in Touch
          </span>
          <h1 className="text-5xl md:text-6xl font-serif font-light text-[#2d2a26] leading-[1.1] mb-8">
            Contact Us
          </h1>
          <p className="text-[#5c5853] max-w-2xl mx-auto font-light leading-relaxed text-lg">
            We'd love to hear from you. Reach out to us for orders, catering, or just to say hello!
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: <Phone size={32} />,
              title: 'Phone',
              content: '+91 9111881159',
              href: 'tel:+919111881159',
            },
            {
              icon: <Mail size={32} />,
              title: 'Email',
              content: 'hello@gmcloudkitchen.in',
              href: 'mailto:hello@gmcloudkitchen.in',
            },
            {
              icon: <Instagram size={32} />,
              title: 'Instagram',
              content: '@gmcloudkitchen',
              href: 'https://instagram.com/gmcloudkitchen',
            },
            {
              icon: <MapPin size={32} />,
              title: 'Location',
              content: 'KPHP Colony, Gajularamaram, Hyderabad',
              href: '#',
            },
          ].map((item, index) => (
            <motion.a
              key={item.title}
              href={item.href}
              target={item.title === 'Instagram' ? '_blank' : undefined}
              rel={item.title === 'Instagram' ? 'noopener noreferrer' : undefined}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white border border-[#2d2a26]/10 shadow-sm p-8 rounded-2xl flex flex-col items-center text-center hover:bg-[#f4f0ea] transition-colors group"
            >
              <div className="w-16 h-16 rounded-full bg-[#c25e2a]/10 text-[#c25e2a] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <h3 className="text-[#2d2a26] font-medium uppercase tracking-widest text-sm mb-4">
                {item.title}
              </h3>
              <p className="text-[#5c5853] font-light leading-relaxed">
                {item.content}
              </p>
            </motion.a>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-24 rounded-3xl overflow-hidden h-[400px] border border-[#2d2a26]/10 shadow-md"
        >
          {/* Placeholder for a map, using a generic map image for aesthetic */}
          <img
            src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=2000"
            alt="Map location"
            className="w-full h-full object-cover opacity-80"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>
    </div>
  );
}
