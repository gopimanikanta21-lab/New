import { motion } from 'motion/react';
import { MENU_ITEMS } from '../data/menu';
import { useCartStore } from '../store';
import { Plus, Check } from 'lucide-react';
import { useState } from 'react';

export default function Order() {
  const addItem = useCartStore((state) => state.addItem);
  const cartItems = useCartStore((state) => state.items);
  const [addedItems, setAddedItems] = useState<Record<string, boolean>>({});

  const handleAdd = (item: any) => {
    addItem({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
    });
    setAddedItems((prev) => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedItems((prev) => ({ ...prev, [item.id]: false }));
    }, 2000);
  };

  const categories = Array.from(new Set(MENU_ITEMS.map((item) => item.category)));

  return (
    <div className="w-full bg-[#fdfbf7] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-6 block">
            Order Online
          </span>
          <h1 className="text-5xl md:text-6xl font-serif font-light text-[#2d2a26] leading-[1.1] mb-8">
            Our Menu
          </h1>
        </motion.div>

        {categories.map((category) => (
          <div key={category} className="mb-20">
            <h2 className="text-3xl font-serif font-light text-[#2d2a26] mb-10 border-b border-[#2d2a26]/10 pb-4">
              {category}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {MENU_ITEMS.filter((item) => item.category === category).map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#2d2a26]/5 group flex flex-col"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/5" />
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-serif text-[#2d2a26]">{item.name}</h3>
                      <span className="text-[#c25e2a] font-medium">₹{item.price}</span>
                    </div>
                    <p className="text-[#5c5853] text-sm font-light leading-relaxed mb-6 flex-grow">
                      {item.description}
                    </p>
                    <button
                      onClick={() => handleAdd(item)}
                      className={`w-full py-3 rounded-full flex items-center justify-center gap-2 text-sm uppercase tracking-widest font-semibold transition-all ${
                        addedItems[item.id]
                          ? 'bg-green-600 text-white'
                          : 'bg-[#f4f0ea] text-[#2d2a26] hover:bg-[#c25e2a] hover:text-white'
                      }`}
                    >
                      {addedItems[item.id] ? (
                        <>
                          <Check size={18} /> Added
                        </>
                      ) : (
                        <>
                          <Plus size={18} /> Add to Cart
                        </>
                      )}
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
