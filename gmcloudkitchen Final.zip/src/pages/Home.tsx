import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star } from 'lucide-react';

export default function Home() {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1589301760014-d929f39ce9b1?auto=format&fit=crop&q=80&w=2000"
            alt="Delicious South Indian Food"
            className="w-full h-full object-cover opacity-80"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#2d2a26] via-[#2d2a26]/60 to-transparent" />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-6 block">
              Authentic Andhra Flavors
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-light text-white leading-[1.1] mb-8">
              Taste the <br />
              <span className="italic text-[#f4f0ea]">Tradition</span>
            </h1>
            <p className="text-lg md:text-xl text-[#f4f0ea] mb-10 max-w-2xl mx-auto font-light leading-relaxed">
              From our kitchen to your table. Experience the rich, authentic taste of Andhra Pradesh right here in Hyderabad.
            </p>
            <Link
              to="/order"
              className="inline-flex items-center justify-center gap-3 bg-[#c25e2a] text-white px-8 py-4 rounded-full text-sm uppercase tracking-widest font-semibold hover:bg-[#a64d20] transition-all hover:scale-105"
            >
              Order Now <ArrowRight size={18} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Items Section */}
      <section className="py-24 bg-[#fdfbf7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div>
              <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-4 block">
                Our Specialties
              </span>
              <h2 className="text-4xl md:text-5xl font-serif font-light text-[#2d2a26]">
                Signature Dishes
              </h2>
            </div>
            <Link
              to="/order"
              className="text-[#5c5853] hover:text-[#c25e2a] flex items-center gap-2 uppercase tracking-widest text-sm font-medium transition-colors"
            >
              View Full Menu <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Andhra Meals',
                price: '₹120',
                image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&q=80&w=800',
              },
              {
                name: 'Special Biryani',
                price: '₹250',
                image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&q=80&w=800',
              },
              {
                name: 'Crispy Dosa',
                price: '₹50',
                image: 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&q=80&w=800',
              },
            ].map((item, index) => (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, duration: 0.6 }}
                className="group cursor-pointer"
              >
                <div className="relative overflow-hidden rounded-2xl aspect-[4/5] mb-6 shadow-md">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-500" />
                </div>
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-serif text-[#2d2a26]">{item.name}</h3>
                  <span className="text-[#c25e2a] font-medium">{item.price}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial / Quality Section */}
      <section className="py-24 bg-[#f4f0ea] border-y border-[#2d2a26]/5">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex justify-center gap-1 text-[#c25e2a] mb-8">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} size={24} fill="currentColor" />
            ))}
          </div>
          <h3 className="text-3xl md:text-4xl font-serif font-light text-[#2d2a26] leading-relaxed mb-8">
            "We are from Andhra Pradesh and we are happy to serve our customers. Your happiness and health care are our top priorities."
          </h3>
          <p className="text-[#5c5853] uppercase tracking-widest text-sm font-medium">
            — The GMCloudKitchen Team
          </p>
        </div>
      </section>
    </div>
  );
}
