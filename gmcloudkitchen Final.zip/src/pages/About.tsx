import { motion } from 'motion/react';

export default function About() {
  return (
    <div className="w-full bg-[#fdfbf7] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-6 block">
              Our Story
            </span>
            <h1 className="text-5xl md:text-6xl font-serif font-light text-[#2d2a26] leading-[1.1] mb-8">
              From Andhra <br />
              <span className="italic text-[#8a857e]">with Love</span>
            </h1>
            <div className="space-y-6 text-[#5c5853] font-light leading-relaxed text-lg">
              <p>
                We are from Andhra Pradesh, and we are happy to serve our customers.
                Our journey started with a simple passion for authentic, home-cooked
                meals that bring people together.
              </p>
              <p>
                At GMCloudKitchen, the happiness of our customers is our top priority.
                We believe that good food is the foundation of good health, which is why
                we take immense care in preparing every dish. We use fresh ingredients,
                traditional recipes, and a whole lot of love.
              </p>
              <p>
                Whether you're craving a comforting plate of Idly or a rich, aromatic
                Biryani, we are here to deliver a taste of home straight to your door in
                Hyderabad.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden relative shadow-xl">
              <img
                src="https://images.unsplash.com/photo-1589301760014-d929f39ce9b1?auto=format&fit=crop&q=80&w=1200"
                alt="Cooking with love"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2d2a26]/40 to-transparent" />
            </div>
            <div className="absolute -bottom-8 -left-8 bg-white p-8 rounded-2xl border border-[#2d2a26]/10 shadow-2xl max-w-xs">
              <p className="text-[#c25e2a] font-serif text-4xl mb-2">100%</p>
              <p className="text-[#2d2a26] font-medium uppercase tracking-widest text-sm">
                Authentic Taste
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
