import { motion } from 'motion/react';
import { useCartStore } from '../store';
import { Minus, Plus, Trash2, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { useState } from 'react';

export default function Checkout() {
  const { items, updateQuantity, removeItem, total, clearCart } = useCartStore();
  const [step, setStep] = useState<'cart' | 'payment'>('cart');
  const navigate = useNavigate();

  const handleConfirmOrder = () => {
    // In a real app, you'd send order data to a backend here
    clearCart();
    navigate('/tracking');
  };

  const upiId = '9111881159@ybl'; // Example UPI ID
  const amount = total();
  const upiUrl = `upi://pay?pa=${upiId}&pn=GMCloudKitchen&am=${amount}&cu=INR`;

  if (items.length === 0 && step === 'cart') {
    return (
      <div className="w-full bg-[#fdfbf7] min-h-screen py-24 flex flex-col items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-8 border border-[#2d2a26]/10 shadow-sm">
            <Trash2 size={40} className="text-[#8a857e]" />
          </div>
          <h2 className="text-3xl font-serif font-light text-[#2d2a26] mb-4">Your cart is empty</h2>
          <p className="text-[#5c5853] mb-8 font-light">Looks like you haven't added anything yet.</p>
          <Link
            to="/order"
            className="inline-flex items-center justify-center gap-3 bg-[#c25e2a] text-white px-8 py-4 rounded-full text-sm uppercase tracking-widest font-semibold hover:bg-[#a64d20] transition-all"
          >
            Browse Menu <ArrowRight size={18} />
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="w-full bg-[#fdfbf7] min-h-screen py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-6 block">
            {step === 'cart' ? 'Review Order' : 'Secure Payment'}
          </span>
          <h1 className="text-5xl md:text-6xl font-serif font-light text-[#2d2a26] leading-[1.1] mb-8">
            {step === 'cart' ? 'Checkout' : 'Pay via UPI'}
          </h1>
        </motion.div>

        {step === 'cart' ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-6">
              {items.map((item) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex items-center gap-6 bg-white p-4 rounded-2xl border border-[#2d2a26]/10 shadow-sm"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-24 h-24 object-cover rounded-xl"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-grow">
                    <h3 className="text-xl font-serif text-[#2d2a26] mb-2">{item.name}</h3>
                    <span className="text-[#c25e2a] font-medium">₹{item.price}</span>
                  </div>
                  <div className="flex items-center gap-4 bg-[#f4f0ea] rounded-full p-2 border border-[#2d2a26]/5">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full flex items-center justify-center text-[#5c5853] hover:text-[#2d2a26] hover:bg-[#2d2a26]/5 transition-colors"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="text-[#2d2a26] font-medium w-4 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full flex items-center justify-center text-[#5c5853] hover:text-[#2d2a26] hover:bg-[#2d2a26]/5 transition-colors"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="p-3 text-[#8a857e] hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={20} />
                  </button>
                </motion.div>
              ))}
            </div>

            <div className="bg-white p-8 rounded-3xl border border-[#2d2a26]/10 shadow-sm h-fit sticky top-28">
              <h3 className="text-2xl font-serif text-[#2d2a26] mb-6">Order Summary</h3>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-[#5c5853] font-light">
                  <span>Subtotal</span>
                  <span>₹{total()}</span>
                </div>
                <div className="flex justify-between text-[#5c5853] font-light">
                  <span>Delivery Fee</span>
                  <span>₹40</span>
                </div>
                <div className="flex justify-between text-[#5c5853] font-light">
                  <span>Taxes</span>
                  <span>₹{(total() * 0.05).toFixed(2)}</span>
                </div>
                <div className="pt-4 border-t border-[#2d2a26]/10 flex justify-between text-[#2d2a26] font-medium text-xl">
                  <span>Total</span>
                  <span className="text-[#c25e2a]">
                    ₹{(total() + 40 + total() * 0.05).toFixed(2)}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setStep('payment')}
                className="w-full py-4 rounded-full flex items-center justify-center gap-2 bg-[#c25e2a] text-white text-sm uppercase tracking-widest font-semibold hover:bg-[#a64d20] transition-all"
              >
                Proceed to Pay <ArrowRight size={18} />
              </button>
            </div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-12 rounded-3xl border border-[#2d2a26]/10 shadow-sm max-w-xl mx-auto text-center"
          >
            <h3 className="text-2xl font-serif text-[#2d2a26] mb-4">Scan to Pay</h3>
            <p className="text-[#5c5853] font-light mb-8">
              Open your UPI app and scan the QR code below to complete your payment of{' '}
              <span className="text-[#c25e2a] font-medium">
                ₹{(total() + 40 + total() * 0.05).toFixed(2)}
              </span>
            </p>

            <div className="bg-[#fdfbf7] p-8 rounded-2xl inline-block mb-8 border border-[#2d2a26]/5">
              <QRCodeSVG value={upiUrl} size={200} />
            </div>

            <p className="text-[#8a857e] text-sm mb-8">UPI ID: {upiId}</p>

            <div className="flex flex-col gap-4">
              <button
                onClick={handleConfirmOrder}
                className="w-full py-4 rounded-full flex items-center justify-center gap-2 bg-green-600 text-white text-sm uppercase tracking-widest font-semibold hover:bg-green-700 transition-all"
              >
                I have paid, Confirm Order
              </button>
              <button
                onClick={() => setStep('cart')}
                className="w-full py-4 rounded-full flex items-center justify-center gap-2 bg-transparent border border-[#2d2a26]/20 text-[#2d2a26] text-sm uppercase tracking-widest font-semibold hover:bg-[#2d2a26]/5 transition-all"
              >
                Back to Cart
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
