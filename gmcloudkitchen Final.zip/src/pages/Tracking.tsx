import { motion } from 'motion/react';
import { CheckCircle2, Clock, MapPin, Package, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Tracking() {
  const steps = [
    {
      title: 'Order Confirmed',
      description: 'We have received your order.',
      icon: <CheckCircle2 size={24} />,
      status: 'completed',
    },
    {
      title: 'Preparing Food',
      description: 'Our chef is preparing your meal.',
      icon: <Package size={24} />,
      status: 'current',
    },
    {
      title: 'Out for Delivery',
      description: 'Your order is on the way.',
      icon: <MapPin size={24} />,
      status: 'upcoming',
    },
    {
      title: 'Delivered',
      description: 'Enjoy your meal!',
      icon: <Clock size={24} />,
      status: 'upcoming',
    },
  ];

  return (
    <div className="w-full bg-[#fdfbf7] min-h-screen py-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="w-20 h-20 bg-green-500/10 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 size={40} />
          </div>
          <span className="text-[#c25e2a] font-medium tracking-[0.2em] uppercase text-sm mb-4 block">
            Order #GM{Math.floor(Math.random() * 100000)}
          </span>
          <h1 className="text-4xl md:text-5xl font-serif font-light text-[#2d2a26] leading-[1.1] mb-6">
            Order Successful!
          </h1>
          <p className="text-[#5c5853] font-light text-lg">
            Thank you for ordering from GMCloudKitchen. Your food will be with you shortly.
          </p>
        </motion.div>

        <div className="bg-white p-8 md:p-12 rounded-3xl border border-[#2d2a26]/10 shadow-sm mb-12">
          <h3 className="text-2xl font-serif text-[#2d2a26] mb-10">Track Order</h3>
          
          <div className="relative">
            {/* Connecting line */}
            <div className="absolute left-6 top-6 bottom-6 w-0.5 bg-[#2d2a26]/10" />

            <div className="space-y-12">
              {steps.map((step, index) => (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="relative flex items-start gap-6"
                >
                  <div
                    className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center border-4 border-white ${
                      step.status === 'completed'
                        ? 'bg-green-600 text-white'
                        : step.status === 'current'
                        ? 'bg-[#c25e2a] text-white'
                        : 'bg-[#f4f0ea] text-[#8a857e]'
                    }`}
                  >
                    {step.icon}
                  </div>
                  <div className="pt-2">
                    <h4
                      className={`text-lg font-medium mb-1 ${
                        step.status === 'upcoming' ? 'text-[#8a857e]' : 'text-[#2d2a26]'
                      }`}
                    >
                      {step.title}
                    </h4>
                    <p className="text-[#5c5853] font-light text-sm">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div className="text-center">
          <Link
            to="/"
            className="inline-flex items-center justify-center gap-3 bg-transparent border border-[#2d2a26]/20 text-[#2d2a26] px-8 py-4 rounded-full text-sm uppercase tracking-widest font-semibold hover:bg-[#2d2a26]/5 transition-all"
          >
            Back to Home <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </div>
  );
}
